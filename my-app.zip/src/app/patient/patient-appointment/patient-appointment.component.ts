import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-appointment',
  templateUrl: './patient-appointment.component.html',
  styleUrls: ['./patient-appointment.component.css']
})
export class PatientAppointmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
