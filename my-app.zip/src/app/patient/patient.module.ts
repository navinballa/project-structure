import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddPatientComponent } from './add-patient/add-patient.component';
import { PatientListComponent } from './patient-list/patient-list.component';
import { RouterModule, Routes } from '@angular/router';
import { PatientAppointmentComponent } from './patient-appointment/patient-appointment.component';

const routes: Routes = [
  {
    path: 'add-patient',
    component: AddPatientComponent,
  },
  {
    path: 'patient-list',
    component: PatientListComponent,
  },
  {
    path: 'appointment',
    component: PatientAppointmentComponent,
  },
];

@NgModule({
  declarations: [
    AddPatientComponent,
    PatientListComponent,
    PatientAppointmentComponent,
  ],
  imports: [CommonModule, RouterModule.forChild(routes)],
})
export class PatientModule {}
