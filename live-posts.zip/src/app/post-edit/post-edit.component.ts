import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Post } from '../models/post.model';
import { AuthService } from '../services/auth.service';
import { PostService } from '../services/post.service';

@Component({
  selector: 'app-post-edit',
  templateUrl: './post-edit.component.html',
  styleUrls: ['./post-edit.component.css'],
})
export class PostEditComponent implements OnInit {
  form: FormGroup = new FormGroup({});
  index = -1;

  email?: string | null = null;

  constructor(
    private postService: PostService,
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    console.log('I am constructor');
  }

  ngOnInit(): void {
    this.authService.userUpdated.subscribe((user) => {
      // receining alert

      this.email = user?.email;
    });

    console.log('I am ngOnInit');

    this.form = new FormGroup({
      title: new FormControl(null, [Validators.required]),
      description: new FormControl(null, [Validators.required]),
      imagePath: new FormControl(null, [Validators.required]),
    });

    this.route.params.subscribe((params) => {
      if (params['index']) {
        this.index = params['index'];

        const ob = this.postService.getSinglePost(this.index);
        console.log(ob);

        this.form.controls['title'].setValue(ob.title);
        this.form.controls['description'].setValue(ob.description);
        this.form.controls['imagePath'].setValue(ob.imagePath);
      }
    });
  }

  ngOnChanges() {
    console.log('I am ngOnChanges');
  }

  ngOnDestroy() {
    console.log('I am ngOnDestroy');
  }

  onSubmit() {
    // Validation
    if (this.email === null) {
      alert('You must be logged in');
      return;
    }

    const ob = new Post(
      this.form.value.title,
      this.form.value.description,
      this.form.value.imagePath,
      'test@test.com',
      new Date()
    );

    if (this.index === -1) {
      this.postService.addPost(ob);
    } else {
      this.postService.updatePost(this.index, ob);
    }

    this.router.navigate(['/post-list']);
  }
}
