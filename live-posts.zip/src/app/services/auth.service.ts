import { Location } from '@angular/common';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

export interface User {
  email: string;
  role: USER_TYPE;
}

export enum USER_TYPE {
  ADMIN = 'ADMIN',
  GUEST = 'GUEST',
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  userUpdated = new BehaviorSubject<User | null>(null);

  constructor(private router: Router, private location: Location) {
    // this.userUpdated.next(localStorage.getItem('EMAIL'));
  }

  // Login
  login(email: string, password: string) {
    // Communicateion with backend for email & password check
    const success = email === 'test@test.com' && password === '1234';

    if (success) {
      localStorage.setItem('JWT', 'FJGDJHBFJDH@&');
      localStorage.setItem('EMAIL', email);

      const ob: User = {
        email: email,
        role: USER_TYPE.ADMIN,
      };
      this.userUpdated.next(ob); // Sending ALERT

      //this.router.navigate(['/post-list']);
      this.location.back();
    } else {
      alert('Login Failed');
      localStorage.clear();
    }
  }

  // Singup
  signup(email: string, password: string) {
    // Communicateion with backend for email & password check
    const success = true;

    if (success) {
      localStorage.setItem('JWT', 'FJGDJHBFJDH@&');
      localStorage.setItem('EMAIL', email);

      const ob: User = {
        email: email,
        role: USER_TYPE.ADMIN,
      };
      this.userUpdated.next(ob); // Sending ALERT
      this.router.navigate(['/post-list']);
    } else {
      alert('Signup Failed');
      localStorage.clear();
    }
  }

  // Signout
  signout() {
    // Communicatation with backend for signup

    localStorage.clear();
    this.userUpdated.next(null); // Sending ALERT
    this.router.navigate(['/auth']);
  }
}
