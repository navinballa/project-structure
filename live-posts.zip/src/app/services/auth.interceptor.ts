import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  jwt = localStorage.getItem('JWT');
  email = localStorage.getItem('EMAIL_ID');
  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    request = request.clone({
      setHeaders: {
        JWT: this.jwt ? this.jwt : "DEFAULT",
        EMAIL: this.email ? this.email : "DEFAULT_EMAIL"
      },
    });

    return next.handle(request);
  }
}
