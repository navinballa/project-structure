import { Component, OnInit } from '@angular/core';
import { AuthService, User } from '../services/auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  email?: string | null = null;
  constructor(private authService: AuthService) {}

  ngOnInit(): void {
    this.authService.userUpdated.subscribe((user) => {
      // receining alert

      this.email = user?.email;
    });
  }

  onSignout() {
    this.authService.signout();
  }
}
